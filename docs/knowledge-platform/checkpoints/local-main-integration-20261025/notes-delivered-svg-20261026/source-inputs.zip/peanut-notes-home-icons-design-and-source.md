# 花生笔记首页 · 5 枚 SVG 图形资产（v1）

> 本批交付五枚可维护透明 SVG、视觉检查图与独立 Codex 接入指令。设计交付不等于小程序已接入。

## 图形与来源

| 入口 | 文件 | 来源 | 接入角色 |
|---|---|---|---|
| 每日快记 | `daily-quick-review.svg` | 新设计 | 大型低透明度背景纹理 |
| 全部知识 | `all-knowledge.svg` | 复用政治已确认 A-V2 | 浅绿色重点卡左侧目录图形 |
| 方法判断 | `method-selection.svg` | 新设计 | 浅蓝圆底 / 方法识别 |
| 考前速记 | `exam-recall.svg` | 复用政治「考前速记」 | 浅橙圆底 / 主动回忆 |
| 完整题应用 | `full-problem-application.svg` | 新设计 | 浅青绿圆底 / 完整题应用 |

## 设计规格与注意

- 统一 `viewBox="0 0 128 128"`，SVG 文件透明背景；不内置圆形容器、阴影、滤镜、字体、图片或渐变。
- 保留饱满几何色面、少量纯色叠层、同族光学重量：日常主蓝辅绿，考前速记沿用橙蓝；避免为了统一而把所有剪影都画成书本。
- 全部知识原样复用政治 A-V2、考前速记原样复用政治已确认记忆卡。图形可复用，**学习记录与业务状态不可复用**。
- 常规学习卡建议同尺寸 48px 浅色圆底+约 30–34px SVG 可见主体；主入口不加圆形底座。所有尺寸以真机缩小后视觉结果校准。
- `preview.png` 是设计总览；`preview-small.png` 是小尺寸查看；`layout-preview.png` 是卡片结构示意，**不是微信开发者工具当前运行截图**，示例文字不可覆盖真实业务动态状态。
- 页面还存在可单独开展的文案精炼机会（如「方法判断」的长副文案），但本批默认不修改文案、布局或功能。

## Codex 接入指令（独立副本 CODEX-INSTRUCTIONS.md）

# Codex｜花生笔记首页 SVG 图形接入（五枚，独立视觉批次）

## 一、目标与现状

基于用户最新提供的「花生笔记」真实页面截图，将首页 **5 处虚线占位图**替换为本资产包的 5 个 SVG 图形。
当前占位对应：每日快记、全部知识、方法判断、考前速记、完整题应用。**不得擅自新增第四张学习方式卡，也不应把笔记理解为用户自行记录的私人笔记。**

## 二、P0｜基线与资产核对

1. 在现有笔记模块所属 worktree 上只读检查当前首页、图形加载、局部样式及工作区状态；保存真实界面 baseline 与独立可恢复 checkpoint。
2. 读取此包五枚原始 SVG 与 README。全部采用透明背景、`128×128 viewBox`、纯色几何图元。禁止以截图重画、修改原始 path、修改色值、添加阴影或改成 3D。
3. `all-knowledge.svg` 与政治/常识同一原始来源；`exam-recall.svg` 与政治「考前速记」同一来源。避免复制后产生多个不同版本的同义图形。
4. 检查微信小程序 SVG 资源兼容性与现有资源管线。若不能直接稳定使用，基于原 SVG **确定性导出透明 PNG @2x/@3x**，保留源 SVG 为设计母版，避免额外图像生成。

## 三、P1｜逐一接入

- **每日快记**：`daily-quick-review.svg`。在当前蓝紫青多色渐变卡片的右半作为大型半透明背景纹理，不作为单独的前景图标。先试 150–190px 视觉宽度、12%–20% 不透明度，允许被卡片外轮廓裁切。不要遮挡或挤压右下「开始快记」按钮。保留原按钮真实文案与操作。
- **全部知识**：`all-knowledge.svg`。替换当前浅绿色卡片左侧虚线占位；可见图形先试 48–56px，容器约 60px，按光学重量调整。保留标题、真实科目/知识点计数和「进入」动作；不要硬编码截图里的 5 和 162。
- **方法判断**：`method-selection.svg`。浅蓝统一圆形底座，表达通过信号判断适用方法，不是答题判对错。
- **考前速记**：`exam-recall.svg`。与政治首页复用同语义橙蓝记忆卡，底座采用浅暖橙，保留笔记独立的实际筛选及回忆逻辑。
- **完整题应用**：`full-problem-application.svg`。浅青绿圆形底座，表达在已有完整题目中应用方法，非新建试题或内容创作。

## 四、P2｜四区栅格和容器

三张学习卡共用「左内边距 → 48px 圆形底座 → 文字两行 → 固定尾箭头」的栅格，内层图形可见尺寸先试 30–34px，并允许少量**等比例光学校准**。圆形底色属于 WXML/WXSS 容器，不写入 SVG 原文件。

确保三卡的：圆形中心线、标题文字起点、副文案起点、尾箭头中心线完全一致；不因图形透明留白不同而修改文字布局。三卡背景保留白色，避免在圆底之外再加大块彩色渐变。

每日快记主按钮为直接动作；全部知识是整卡资源入口；三张学习方式是整卡路径入口。**按任务类型统一动作语义，而不是强制所有入口都显示按钮。**

## 
## 


## 全部 SVG 原始源码

### 每日快记 (`daily-quick-review.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128" role="img" aria-label="每日快记">
<rect x="16" y="37" width="91" height="75" rx="14" fill="#2583F4"/>
<rect x="29" y="17" width="85" height="77" rx="14" fill="#DDECFF"/>
<rect x="43" y="34" width="42" height="9" rx="4.5" fill="#77B6F9"/>
<rect x="43" y="53" width="30" height="9" rx="4.5" fill="#92C8FC"/>
<rect x="43" y="74" width="22" height="8" rx="4" fill="#2583F4"/>
<rect x="89" y="67" width="29" height="26" rx="9" fill="#2DC78A"/>
</svg>
```

### 全部知识 (`all-knowledge.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128" role="img" aria-label="全部知识">
<rect x="98" y="35" width="22" height="24" rx="6" fill="#2DC78A"/>
<rect x="98" y="73" width="22" height="24" rx="6" fill="#7CDCB0"/>
<rect x="19" y="15" width="88" height="99" rx="14" fill="#2583F4"/>
<path d="M33 15H40V114H33C25.3 114 19 107.7 19 100V29C19 21.3 25.3 15 33 15Z" fill="#1469D4"/>
<rect x="45" y="31" width="48" height="68" rx="8" fill="#E7F3FF"/>
<rect x="56" y="48" width="26" height="7" rx="3.5" fill="#94C5F8"/>
<rect x="56" y="63" width="20" height="7" rx="3.5" fill="#94C5F8"/>
</svg>
```

### 方法判断 (`method-selection.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128" role="img" aria-label="方法判断">
<path d="M64 64H81M81 40V91" fill="none" stroke="#9BCAFD" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
<rect x="11" y="30" width="58" height="70" rx="13" fill="#2583F4"/>
<rect x="24" y="48" width="32" height="8" rx="4" fill="#C5E4FF"/>
<rect x="24" y="65" width="23" height="8" rx="4" fill="#C5E4FF"/>
<rect x="81" y="19" width="36" height="39" rx="11" fill="#2DC78A"/>
<rect x="81" y="73" width="36" height="39" rx="11" fill="#86BEFA"/>
</svg>
```

### 考前速记 (`exam-recall.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128" role="img" aria-label="考前速记">
<rect x="29" y="27" width="83" height="91" rx="14" fill="#2583F4"/>
<rect x="16" y="13" width="83" height="91" rx="14" fill="#F5AD45"/>
<rect x="30" y="40" width="47" height="9" rx="4.5" fill="#FFFFFF"/>
<rect x="30" y="58" width="32" height="9" rx="4.5" fill="#FFE3B0"/>
<rect x="30" y="76" width="20" height="9" rx="4.5" fill="#FFE3B0"/>
</svg>
```

### 完整题应用 (`full-problem-application.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128" role="img" aria-label="完整题应用">
<path d="M27 14H81L108 42V107C108 113 103 118 97 118H27C19 118 14 112 14 104V28C14 20 19 14 27 14Z" fill="#2583F4"/>
<path d="M81 14V34C81 39 85 42 90 42H108Z" fill="#83BDFB"/>
<rect x="29" y="47" width="42" height="8" rx="4" fill="#C7E5FF"/>
<rect x="29" y="65" width="32" height="8" rx="4" fill="#C7E5FF"/>
<rect x="75" y="78" width="42" height="38" rx="11" fill="#2DC78A"/>
<rect x="84" y="91" width="24" height="9" rx="4.5" fill="#D9F7E9"/>
</svg>
```
